<?php

namespace App\Command;

class Job
{

}