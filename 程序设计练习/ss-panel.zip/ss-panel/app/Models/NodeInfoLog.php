<?php


namespace App\Models;


class NodeInfoLog extends Model
{
    protected $table = "ss_node_info_log";

}